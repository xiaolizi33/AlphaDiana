"""Render the depth-six extension from frozen numeric records and real traces."""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import campaign as core
from deepen_math import ROOT


def load_rows(split, depth):
    if depth < 3 and not (depth == 0 and split == 'D'):
        label = {0: 'base', 1: 'A', 2: 'AC'}[depth]
        path = ROOT / 'imported/results' / f'math500_formal_{split}_{label}.jsonl'
    else:
        path = ROOT / 'results' / f'math500_formal_{split}_L{depth}.jsonl'
    return core.read_rows(path)


def main():
    summary = json.loads((ROOT / 'summary.json').read_text())
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    if summary['protocol_hash'] != protocol['hash']:
        raise ValueError('Summary and protocol mismatch')
    if summary['strategy_layers'] != 6:
        raise ValueError('Six strategy layers were not reached')
    depths = list(range(7))
    generation = [summary['rounds'][str(d)]['G']['accuracy'] * 100 for d in depths]
    development = [summary['rounds'][str(d)]['D']['accuracy'] * 100 for d in depths]
    plt.rcParams.update({'font.family': 'sans-serif',
                         'font.sans-serif': ['DejaVu Sans', 'Arial', 'Helvetica'],
                         'text.usetex': False})
    fig, ax = plt.subplots(figsize=(9, 4.8))
    ax.plot(depths, generation, color='#5B0DAD', lw=1.4, marker='o', label='Generation G (10 tasks)')
    ax.plot(depths, development, color='#5BBCCA', lw=1.4, marker='s', label='Development D (20 tasks)')
    ax.axhline(development[0], color='#3D78C2', lw=1.5, ls='--', label='Base development')
    ax.axvline(2.5, color='#777777', lw=1.2, ls='--', alpha=.85, label='Four-layer extension begins')
    ax.set(xlim=(-.15, 6.15), ylim=(-2, 104), xticks=depths,
           xlabel='Accumulated strategy layers (base = 0)', ylabel='Accuracy (%)')
    ax.set_title('One MATH-500 chain; layers 1-2 imported, layers 3-6 newly generated', fontsize=11)
    ax.tick_params(direction='out', length=4, width=.8)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1)
    ax.grid(False)
    ax.legend(loc='lower right', fontsize=9, frameon=True, facecolor='white', edgecolor='#AAAAAA')
    fig.tight_layout(pad=.8)
    fig.savefig(ROOT / 'depth_curve.png', dpi=300, facecolor='white')
    plt.close(fig)
    with (ROOT / 'depth_results.csv').open('w') as file:
        writer = csv.writer(file)
        writer.writerow(['strategy_layers', 'upstream_depth', 'G_correct', 'G_n', 'D_correct', 'D_n', 'origin'])
        for depth in depths:
            row = summary['rounds'][str(depth)]
            writer.writerow([depth, depth + 1, row['G']['correct'], row['G']['n'], row['D']['correct'], row['D']['n'],
                             'imported' if depth in [1, 2] else 'imported G; new D' if depth == 0 else 'new'])
    current = {row['task_id']: row for row in load_rows('G', 6)}
    parent = {row['task_id']: row for row in load_rows('G', 5)}
    changed = [key for key in current if current[key]['correct'] != parent[key]['correct']]
    key = (changed or list(current))[0]
    case = {'task_id': key, 'split': 'G', 'selection_rule': 'First G task with changed correctness from depth5 to depth6; otherwise first G task',
            'posthoc_illustration': True, 'rows': {str(d): next(row for row in load_rows('G', d) if row['task_id'] == key) for d in depths}}
    (ROOT / 'case_trajectory.json').write_text(json.dumps(case, ensure_ascii=False, indent=2) + '\n')
    case_lines = ['# 六层执行代表轨迹', '', f'题目 `{key}`，来自 G 集。案例在运行完成后按明确规则选择，用于查看层间传递。', '',
                  case['rows']['6']['problem'], '', '|策略层数|输出|正确|实际预处理顺序|', '|---:|---|---|---|']
    for depth, row in case['rows'].items():
        events = row['metadata'].get('layer_events', [])
        case_lines.append(f"|{depth}|{row['predicted']}|{row['correct']}|{' → '.join(str(e['depth']) for e in events)}|")
    case_lines += ['', '## 第六层实际上下文传递', '', '|官方层深度|收到的外层上下文字符数|本层输出上下文字符数|', '|---:|---:|---:|']
    for event in case['rows']['6']['metadata']['layer_events']:
        case_lines.append(f"|{event['depth']}|{len(event['outer_context'])}|{len(event['context'])}|")
    case_lines += ['', '完整逐层请求、生成代码、执行程序与轨迹见 case_trajectory.json、strategies/ 和 results/。单条链上的观察不能隔离某条指令的因果效应。']
    (ROOT / 'case_trajectory.md').write_text('\n'.join(case_lines) + '\n')
    requests = [json.loads(path.read_text()) for path in (ROOT / 'requests').glob('*.json')]
    strategy_records = []
    for path in (ROOT / 'strategies').glob('L*.json'):
        record = json.loads(path.read_text())
        if isinstance(record, dict) and 'injection' in record:
            strategy_records.append(record)
    omega_tokens = sum(r['token_usage']['total_tokens'] for r in strategy_records)
    accounting = {'new_generation_tokens': omega_tokens,
                  'new_solver_tokens': summary['new_physical_tokens'] - omega_tokens,
                  'new_total_tokens': summary['new_physical_tokens'],
                  'new_reservation_cny': summary['new_reserved_cny'],
                  'request_journals': len(requests),
                  'failed_requests': sum(r['status'] != 'complete' for r in requests),
                  'valid_strategy_draws': sum(r['valid'] for r in strategy_records),
                  'invalid_strategy_draws': sum(not r['valid'] for r in strategy_records)}
    (ROOT / 'token_accounting.json').write_text(json.dumps(accounting, indent=2) + '\n')
    lines = ['# MATH-500 累计六层递归扩展', '',
             '按用户指定，从第 3 次修复后实验的 A+C 继续生成四个外层，累计六层策略。前两层与其 G/D 评分沿用原始记录，每个新外层均读取完整祖先策略源码、当前 G 轨迹、当前分数及上一代基线反馈。官方编号为 base=1、六层策略求解器=7。', '',
             '|策略层数|官方深度|G 正确数|D 正确数|来源|', '|---:|---:|---:|---:|---|']
    for depth in depths:
        row = summary['rounds'][str(depth)]
        origin = '沿用' if depth in [1, 2] else 'G 沿用，D 新运行' if depth == 0 else '新增生成并执行'
        lines.append(f"|{depth}|{depth+1}|{row['G']['correct']}/10|{row['D']['correct']}/20|{origin}|")
    best = summary['development_best_depth']
    lines += ['', f'开发集选中策略层数 {best}，平分时选浅层。深度选择冻结后再执行测试。', '',
              '|测试对象|正确数|准确率|', '|---|---:|---:|']
    for label, row in summary['test'].items():
        lines.append(f"|{label}|{row['correct']}/{row['n']}|{row['accuracy']:.2%}|")
    lines += ['', '![逐层准确率](depth_curve.png)', '',
              f"本阶段新增 {accounting['new_total_tokens']:,} token，其中 Ω 生成 {omega_tokens:,}，求解 {accounting['new_solver_tokens']:,}。新增保守费用预留 ¥{accounting['new_reservation_cny']:.6f}，阶段上限 ¥85，项目累计保护上限 ¥250。沿用前两层的历史消耗未重复计入本阶段。", '',
              '代表题、完整六层上下文传递与输出见 case_trajectory.md 和 case_trajectory.json。每轮 audits/ 和 rounds/ 记录深度、输入来源哈希、实际执行顺序与策略链哈希。', '',
              '## 解释范围', '',
              '这是沿一条既有链连续加深的探索性实验。旧测试集结果在设计扩展前已知，新增策略生成仅使用 G，深度选择仅使用 D。本次没有为四次额外生成机会配置等预算独立搜索对照，也没有新增独立数据划分。', '',
              '为容纳六层源码和指导，输入容量上限提高到 solver 64,000、Ω 160,000 的保守 token 边界；模型别名、温度、输出上限和评分器沿用原协议。观察到的质量变化同时包含策略改变和解题采样波动，单次链扩展不能建立一般性的递归收益结论。']
    (ROOT / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'test': summary['test'], 'best_depth': best, 'accounting': accounting}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
